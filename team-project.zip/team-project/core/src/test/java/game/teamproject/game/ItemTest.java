package game.teamproject.game;

import org.junit.Test;

public class ItemTest {

    @Test
    public void getItemName() {
        //Item aItem = new Item("Big Apple", 0);
        //assertEquals("Big Apple", aItem.getItemName());
    }

    @Test
    public void getItemDetails() {
        //Item aItem = new Item("Big Apple", 0);
        //assertNull(aItem.getItemDetails());
    }

    @Test
    public void getItemEffect() {
        //Item aItem = new Item("Big Apple", 0);
        //assertEquals(0, aItem.getItemEffect());
    }

    @Test
    public void toString1() {
        //Item aItem = new Item("Big Apple", 2);
        //assertEquals("Name: Big Apple, Details: null, Effect: 2", aItem.toString());

        //Item aItem2 = new Item("Pluto", 100);
        //assertEquals("Name: Pluto, Details: null, Effect: 100", aItem2.toString());
    }
}
package game.teamproject.game;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BattleLogicTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void dealDamage() {
    }

    @Test
    public void applyDebuff() {
    }
}
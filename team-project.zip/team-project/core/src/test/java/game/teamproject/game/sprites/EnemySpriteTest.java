package game.teamproject.game.sprites;

import org.junit.After;
import org.junit.Before;

public class EnemySpriteTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
}
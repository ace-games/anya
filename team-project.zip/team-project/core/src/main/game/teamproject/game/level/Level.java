package game.teamproject.game.level;

import game.teamproject.game.Characters.Enemy;

public class Level {
    private Enemy enemy;


    public Enemy getEnemy() {
        return enemy;
    }

    public void setEnemy(Enemy enemy) {
        this.enemy = enemy;
    }
}
